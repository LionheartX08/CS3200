%CS 3200 Assignment 1
%Author - Jake Betenson | u0624782

% %experiment 1
% N = 5e5;
% vectorTiming = RandVectorsDP(N);
% x_vectorTiming = 1:10:5e5;
% 
% %plotting semilog
% semilogx(x_vectorTiming,vectorTiming)
% title('Semilogy of Time vs Number of Elements')
% xlabel('N (length of Vector)')
% ylabel('Computation Time (seconds)')
% 
% %plotting conventionally
% plot(n_vectorTiming,vectorTiming)
% title('Computation Time vs Number of Elements')
% xlabel('N (length of Vector)')
% ylabel('Computation Time (seconds)')

% %experiment 2
% N = 6000; %yields approx 2 minutes
% matrixTiming = RandNbyNDP(N);
% x_matrixTiming = 1:10:6000;
% 
% %plotting semilog
% semilogy(x_matrixTiming,matrixTiming)
% title('Semilogy of Time vs Number of Elements')
% xlabel('N (length of Vector)')
% ylabel('Computation Time (seconds)')
% 
% %plotting conventionally
% plot(x_matrixTiming,matrixTiming)
% title('Computation Time vs Number of Elements')
% xlabel('N (length of Vector)')
% ylabel('Computation Time (seconds)')

% %experiment 3
% 
% N = 5e3;
% solveTiming = RandMatrixSolve(N);
% x_SolveTiming = 1:10:N;
% 
% plot(x_SolveTiming,solveTiming)
% xlabel('N (length of Vector)')
% ylabel('Computation Time (seconds)')
% title('Computation Time vs Number of Elements')
% 
% semilogy(x_SolveTiming,solveTiming)
% xlabel('N (length of Vector)')
% ylabel('Computation Time (seconds)')
% title('Semilog of Computation Time vs Number of Elements')

% %experiment 4
% 
% N = 5e3;
% contrivedSolve = ContrivedMatrixSolve(N);
% x_contrivedSolve = 1:10:N;
% 
% plot(x_contrivedSolve,contrivedSolve)
% xlabel('N (length of Vector)')
% ylabel('Computation Time (seconds)')
% title('Computation Time vs Number of Elements')
%title('Model (red) vs Experimental Time (blue)')
fit_test = ModelFit(.0260,2,5000);

%for testing a*(n/1000)^p
function out = ModelFit(a, p, n)
    y = zeros(1, n/10);
    for i = 1:n/10
        y(i)= a*(10*i/1000)^p;
    end
    out = y;
end
        

%Format from https://www.mathworks.com/help/matlab/ref/tic.html
%Specifically Take Measurements using Multiple tic Calls
%Function determines the amount of time taken to solve a contrived 
%Square matrix system of equations from size 1, N
function out = ContrivedMatrixSolve(n)
    tStart = tic;
    T = zeros(1, n/10);
    for i = 1:n/10
        A = zeros(10*i, 10*i);
        A_1 = zeros(10*i-1, 1)-.5;
        A_2 = ones(10*i,1);
        A = A + diag(A_1, 1) + diag(A_1,-1)+ diag(A_2,0);
       
        B = rand(10*i, 1);
        tic
        A\B;
        T(i) = toc;
    end
    out = T;
    tEnd = toc(tStart)
end

%Format from https://www.mathworks.com/help/matlab/ref/tic.html
%Specifically Take Measurements using Multiple tic Calls
%Function determines the amount of time taken to solve a Square matrix
%system of equations from size 1, N
function out = RandMatrixSolve(n)
    tStart = tic;
    T = zeros(1, n/10);
    for i = 1:n/10
        A = rand(10*i, 10*i);
        B = rand(10*i, 1);
        tic
        A\B;
        T(i) = toc;
    end
    out = T;
    tEnd = toc(tStart)
end


%Format from https://www.mathworks.com/help/matlab/ref/tic.html
%Specifically Take Measurements using Multiple tic Calls
%Function determines the amount of time taken to perform N length vector
%dot product from size 1,N
function out = RandVectorsDP(n)
    tStart = tic;
    T = zeros(1,n/10); %timing array
    for i = 1:n/10
        A = rand(10*i,1); %some random column vector between 0,1
        B = rand(1,10*i); %some random row vector between 0,1
        tic %start timing dot product of vectors
        dot(A,B);
        T(i) = toc; %store elapsed time in timing array
    end
    out = T;
    tEnd = toc(tStart)
end

%Format from https://www.mathworks.com/help/matlab/ref/tic.html
%Specifically Take Measurements using Multiple tic Calls
%Function determines the amount of time taken to perform N x N matrix
%dot product from size 1,N
function out = RandNbyNDP(n)
    tStart = tic;
    T = zeros(1,n/10);
    for i = 1:n/10
        A = rand(10*i,10*i); %some random n x n array [0,1]
        B = rand(10*i,10*i); %some random n x n array [0,1]
        tic %start timing dot product of vectors
        dot(A,B);
        T(i) = toc; %store elapsed time in timing array
    end
    out = T;
    tEnd = toc(tStart)
end